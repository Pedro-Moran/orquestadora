package com.bbva.pfmh.dto.jcisconnector.ffmm.investmen;

import com.bbva.pfmh.dto.jcisconnector.ffmm.attributes.EntityName;

public class Country extends EntityName {

}