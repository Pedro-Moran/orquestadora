package com.bbva.pfmh.dto.jcisconnector.ffmm.investmen;

import com.bbva.pfmh.dto.jcisconnector.ffmm.attributes.NumericName;

public class Assets extends NumericName {

}